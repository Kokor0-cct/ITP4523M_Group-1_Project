<?php
session_start();
if (!isset($_SESSION['staff_logged_in'])) {
    header('Location: login.php');
    exit;
}
require_once 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $stmt = $pdo->prepare("INSERT INTO Furnitures (fname, fdesc, fprice) VALUES (?,?,?)");
        $stmt->execute([$_POST['name'], $_POST['desc'], $_POST['price']]);
    } elseif (isset($_POST['edit'])) {
        $stmt = $pdo->prepare("UPDATE Furnitures SET fname=?, fdesc=?, fprice=? WHERE fid=?");
        $stmt->execute([$_POST['name'], $_POST['desc'], $_POST['price'], $_POST['id']]);
    } elseif (isset($_POST['delete'])) {
        $stmt = $pdo->prepare("DELETE FROM Furnitures WHERE fid=?");
        $stmt->execute([$_POST['id']]);
    }
    header('Location: products.php');
    exit;
}
$furnitures = $pdo->query("SELECT * FROM Furnitures ORDER BY fid DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products · Premium Living</title>
    <link rel="stylesheet" href="../CSS/staffStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .table-tools { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 20px; }
        .btn-add { background: #28a745; color: white; padding: 8px 18px; border-radius: 30px; border: none; cursor: pointer; }
        .inline-input { width: auto; display: inline; }
        table input, table button { margin: 2px; }
    </style>
</head>
<body class="body-staff">
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php" class="active">Products</a>
        <a href="materials.php">Materials</a>
        <a href="orders.php">Orders</a>
        <a href="logout.php">Logout</a>
    </div>
    <div class="staff-container">
        <div class="table-box">
            <div class="table-tools">
                <h2><i class="fas fa-boxes"></i> Furniture Products</h2>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="add" value="1">
                    <input type="text" name="name" placeholder="Product name" required size="12">
                    <input type="text" name="desc" placeholder="Description" size="12">
                    <input type="number" step="0.01" name="price" placeholder="Price" required size="6">
                    <button type="submit" class="btn-add">+ Add</button>
                </form>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead><tr><th>ID</th><th>Name</th><th>Description</th><th>Price (HKD)</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($furnitures as $f): ?>
                    <tr>
                        <form method="post">
                            <td><?php echo $f['fid']; ?><input type="hidden" name="id" value="<?php echo $f['fid']; ?>"></td>
                            <td><input type="text" name="name" value="<?php echo htmlspecialchars($f['fname']); ?>" required></td>
                            <td><input type="text" name="desc" value="<?php echo htmlspecialchars($f['fdesc']); ?>"></td>
                            <td><input type="number" step="0.01" name="price" value="<?php echo $f['fprice']; ?>" required></td>
                            <td>
                                <button type="submit" name="edit">Save</button>
                                <button type="submit" name="delete" onclick="return confirm('Delete this product?')">Delete</button>
                            </td>
                        </form>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>